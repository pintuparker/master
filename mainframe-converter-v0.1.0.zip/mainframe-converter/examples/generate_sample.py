"""Generate deterministic synthetic inputs. No production/customer data."""
from pathlib import Path
import argparse


def sample_record(remote=False):
    values = ['CMAS0001', 'PLEX0001', 'CICS0001', 'MON0001', 'RTA0001', 'WLM0001']
    raw = b''.join(v.ljust(8).encode('cp037') for v in values)
    raw += bytes([0x40 if remote else 0x80, 0x02 if remote else 0x01])
    raw += ('AOR' if remote else 'TOR').encode('cp037')
    raw += 'Synthetic CICS start event'.ljust(30).encode('cp037')
    raw += 'APPL0001'.encode('cp037') + ' '.ljust(5).encode('cp037')
    assert len(raw) == 96
    return raw


def generate(directory, count=10):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / 'sample.f.bin').open('wb') as fixed, \
         (directory / 'sample.v.bin').open('wb') as variable, \
         (directory / 'sample.vb.bin').open('wb') as blocked:
        block = bytearray()
        for i in range(count):
            raw = sample_record(bool(i % 2))
            rdw = (100).to_bytes(2, 'big') + b'\0\0' + raw
            fixed.write(raw)
            variable.write(rdw)
            block.extend(rdw)
            if len(block) >= 10000:
                blocked.write((len(block) + 4).to_bytes(2, 'big') + b'\0\0' + block)
                block.clear()
        if block:
            blocked.write((len(block) + 4).to_bytes(2, 'big') + b'\0\0' + block)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='examples/data')
    parser.add_argument('--records', type=int, default=10)
    args = parser.parse_args()
    if args.records < 0:
        parser.error('records must be nonnegative')
    generate(args.output, args.records)
