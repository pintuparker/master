# Mainframe Converter — EMASSTRT implementation, v0.1.0

A runnable, standard-library-only Python package for the supplied EYUL2400 /
EMASSTRT copybook. Uses real process workers, bounded in-flight work, strict
record framing, deterministic ordered CSV parts, output checksums, and staged
publication. Python 3.10+ on local filesystems; Windows uses spawn-compatible
workers. No Spark/JVM dependency.

**Status:** tested engineering baseline for this copybook, not a full Cobrix
replacement or production-certified release. Synthetic tests establish behavior;
production acceptance needs an immutable representative input, confirmed encoding
and transport settings, comparison with trusted output, and workload benchmarks.
No code has been deployed or run against production data.

## Quick start

From the extracted project directory:

```bash
python -m pip install .
python examples/generate_sample.py --output examples/data --records 1000
python -m mainframe_converter --input examples/data/sample.f.bin --copybook examples/EMASSTRT.cpy --output results-fixed --format F --encoding cp037 --workers 4 --batch-records 250
python -m unittest discover -s tests -v
```

For standard variable or variable-blocked transport, use the corresponding
sample.v.bin / sample.vb.bin file and `--format V` / `--format VB`.
`--output` is a NEW directory and must not exist. Reruns use a new directory.
For pipe-delimited output, add `--delimiter '|'`.

The source tree can also run directly without pip installation. The package has
no runtime dependencies; pip builds need setuptools. Offline environments can
use an internally supplied build toolchain or run from the extracted tree.

## Python API

```python
from mainframe_converter import convert

if __name__ == '__main__':  # required for multiprocessing spawn
    result = convert(
        'input.bin', 'examples/EMASSTRT.cpy', 'new-output-directory',
        record_format='F', encoding='cp037', workers=4,
        batch_records=100000, delimiter='|',
    )
    print(result['records'])
```

## Your layout: 96 bytes, zero-based offsets

| Field | Offset | Bytes | CSV representation |
|---|---:|---:|---|
| CMASNAME | 0 | 8 | decoded text |
| PLEXNAME | 8 | 8 | decoded text |
| CSYSNAME | 16 | 8 | decoded text |
| MON-SPEC | 24 | 8 | decoded text |
| RTA-SPEC | 32 | 8 | decoded text |
| WLM-SPEC | 40 | 8 | decoded text |
| STATUS-R | 48 | 1 | uppercase hex: e.g. 80 or 40 |
| DYNROUTE | 49 | 1 | uppercase hex: e.g. 01 or 02 |
| DYNTYPE | 50 | 3 | decoded text: e.g. TOR or AOR |
| DESC | 53 | 30 | decoded text |
| CSYSAPPL | 83 | 8 | decoded text |
| EYU-RSV0015 | 91 | 5 | decoded text |

Level-88 declarations consume no bytes. They create boolean CSV columns such as
STATUS-R__LOCAL, STATUS-R__REMOTE and DYNTYPE__WLMTOR. Conditions are exact raw
byte comparisons, not bitmask tests. Unknown values are preserved in the base
field and yield false for conditions. Fields with any hexadecimal condition
are emitted as hex; this is an explicit output convention and does not claim
Cobrix's schema semantics. Text uses strict decoding and trims trailing spaces
only. Leading spaces and embedded control characters remain intact. CSV uses
UTF-8 with standard quoting, so embedded delimiters/newlines are valid CSV.
The output is a logical-record CSV, not fixed-width text.

The synthetic local record has STATUS-R=80, DYNROUTE=01, DYNTYPE=TOR. The remote
record has 40, 02, AOR. Samples alternate these records. They are generated from
known values, not extracted from a mainframe or independently verified by Cobrix.

## Explicit support boundary

| Feature | v0.1.0 |
|---|---|
| One level-01 root, flat level-02 PIC X / X(n) | Supported |
| Level-88 single text or hexadecimal VALUE | Supported, exact full-field comparison |
| Comments and ordinary numbered source lines | Supported |
| One complete declaration per line | Required |
| F, headerless fixed records | Supported |
| V, inclusive big-endian 4-byte RDW | Supported |
| VB, inclusive big-endian 4-byte BDW and RDW | Supported |
| RDW/BDW reserved bytes | Must be zero; spanned records rejected |
| CP037 | Default, must confirm for actual file |
| Other complete single-byte Python codecs | Configurable, must validate actual data |
| COMP, COMP-3, PIC 9, signed/zoned decimals | Not implemented; rejected |
| Groups, OCCURS/DEPENDING ON, REDEFINES, FILLER | Not implemented; rejected |
| COPY expansion, continuation lines, multiple roots | Not implemented; rejected |
| VBS, little-endian/custom header adjustments | Not implemented; rejected |
| Compressed files, GCS/S3 direct access, Spark | Not implemented |
| Resume/checkpoint, skip/reject output, automatic retries | Not implemented |
| Parquet and reverse mainframe encoding | Not implemented |

Unsupported copybook syntax raises an error. There is no inference that could
quietly shift offsets. FB data exported without physical block headers uses F;
this does not parse arbitrary mainframe block/container formats.

## Execution and operational behavior

- F tasks are record-aligned byte ranges; records are not sent through process
  queues. Each worker opens the file, seeks, decodes, and writes its own CSV part.
- V/VB framing is scanned in the coordinator to find safe boundaries. Workers
  read those ranges again. This extra I/O is deliberate and must be benchmarked.
- VB tasks end at block boundaries. batch-records is a target, so one block can
  exceed it. The scheduler holds at most twice the worker count in-flight.
- A worker processes one record at a time. Manifest metadata grows with the
  number of parts, not the number of records. Avoid tiny batches on large files.
- Read manifest.json parts IN LISTED ORDER to preserve source order. Each part
  has its own header. Do not concatenate headers blindly. Empty input publishes
  a manifest with zero parts and the complete column list.
- Input must remain immutable. Device/inode/size/mtime/ctime checks detect common
  mutations but are not a cryptographic input snapshot or distributed lock.
- Source record counts and per-part SHA-256 hashes are recorded. Copybook hash
  covers the UTF-8 text passed to the parser. Input content hashing is not done.
- No row is silently skipped or replaced. Errors stop the job, wait for active
  workers, clean the staging directory, and return a nonzero CLI exit code.
- A sibling exclusive lock prevents cooperating runs from sharing a destination.
  A hard kill can leave a lock or hidden staging directory. Verify no active run
  before manually removing stale files. There is no automatic stale-lock takeover.
- Successful files are fsynced and a sibling directory is renamed into place.
  This provides publish-on-success visibility on typical local filesystems, not
  a crash-durability guarantee on all filesystems. Directory entries are not
  fsynced. Network/object storage needs its own commit protocol.
- Protect the parent output directory from unrelated writers. The cooperative
  lock does not protect against other applications modifying the destination.
- Staging directories are owner-only by default. Set filesystem ownership and
  retention policies suitable for the deployment environment. Diagnostics do
  not intentionally include record contents.

## Production acceptance work

1. Confirm actual RECFM/export framing, CP037 versus another code page, and that
   the file was transferred in binary mode without newline insertion.
2. Compare all fields and record counts against trusted output from your current
   converter, using the same normalization/hex conventions. Include unknown
   status values, control bytes, empty text, and full-width values.
3. Exercise the supported Python version and OS, job cancellation, disk-full,
   permissions, worker failures, and stale-file recovery in your deployment.
4. Benchmark representative large files at 1, 2, 4, 8 workers. Record elapsed
   time, CPU, memory and disk throughput. More workers can slow an I/O-bound job.
5. Decide whether output ordering, single-file merging, restart checkpoints,
   record-level reject files, cloud input, or other copybook clauses are required.
6. Add numeric/group/array/redefine support behind independently validated
   fixtures before processing copybooks that use those features.

## Repository contents

- mainframe_converter/schema.py: strict parser, immutable layout, decoder
- mainframe_converter/framing.py: F/V/VB framing and partition boundaries
- mainframe_converter/engine.py: multiprocessing, validation and publication
- mainframe_converter/cli.py: CLI, exit status
- examples/EMASSTRT.cpy: supplied layout (commentary shortened)
- examples/generate_sample.py and examples/data: reproducible synthetic inputs
- examples/expected-output: generated conversion output and manifest
- tests/test_conversion.py: correctness, process equivalence, framing errors,
  unsupported syntax, empty input, overwrite prevention and argument validation
- VALIDATION.md: checks run for this delivery

No throughput target or equivalence to full Cobrix is claimed.
