# Delivery validation

Executed in the delivery environment on Python 3 (Linux):

- `python -m unittest discover -s tests -v`: 7 tests passed.
- End-to-end CLI: generated 10 synthetic 96-byte records; two process workers;
  batch size 3; produced 4 ordered CSV parts and a 10-record manifest.
- Cross-format tests: 217 alternating local/remote records in each F/V/VB format,
  run with 1 and 2 workers; every decoded row matched in source order.
- Checked precise field offsets and raw hexadecimal level-88 conditions.
- Checked unsupported grammar, truncated/malformed headers, reserved header bytes,
  payload length mismatches, no partial publish, empty input and no overwrite.

These are functional checks, not a performance benchmark. Tests use synthetic
inputs; no independent Cobrix comparison or actual mainframe data validation has
been performed. Windows and Python-version matrix testing remain outstanding.
See README.md for support boundaries and production acceptance criteria.
