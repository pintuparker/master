"""Record-boundary validation. Standard big-endian inclusive 4-byte RDW/BDW.

Only unspanned V/VB with zero reserved bytes are accepted. Transfer-specific
header adjustments, endianness variants and VBS are intentionally rejected.
"""


def _word(stream, label, limit):
    offset = stream.tell()
    raw = stream.read(4)
    if len(raw) != 4:
        raise ValueError(f'truncated {label} at byte {offset}')
    if raw[2:] != b'\x00\x00':
        raise ValueError(f'unsupported {label} flags/reserved bytes at byte {offset}')
    length = int.from_bytes(raw[:2], 'big')
    if length < 4 or offset + length > limit:
        raise ValueError(f'invalid {label} length {length} at byte {offset}')
    return length


def ranges(path, record_format, length, batch_records):
    """Yield (start, stop, count) with validated boundaries and constant memory."""
    size = path.stat().st_size
    if record_format == 'F':
        if size % length:
            raise ValueError(f'input size {size} is not divisible by record length {length}')
        step = length * batch_records
        for start in range(0, size, step):
            stop = min(size, start + step)
            yield start, stop, (stop - start) // length
        return
    if record_format not in ('V', 'VB'):
        raise ValueError('format must be F, V, or VB')
    with path.open('rb') as stream:
        count = 0
        start = 0
        while stream.tell() < size:
            if record_format == 'VB':
                block_length = _word(stream, 'BDW', size)
                if block_length == 4:
                    raise ValueError('empty VB blocks are unsupported')
                limit = stream.tell() - 4 + block_length
            else:
                limit = size
            while stream.tell() < limit:
                rdw_offset = stream.tell()
                record_length = _word(stream, 'RDW', limit)
                if record_length - 4 != length:
                    raise ValueError(f'payload length {record_length - 4} != {length} at byte {rdw_offset}')
                stream.seek(record_length - 4, 1)
                count += 1
                if record_format == 'V' and count >= batch_records:
                    yield start, stream.tell(), count
                    start, count = stream.tell(), 0
            if record_format == 'VB' and count >= batch_records:
                yield start, stream.tell(), count
                start, count = stream.tell(), 0
        if count:
            yield start, size, count


def records(stream, start, stop, record_format, length):
    stream.seek(start)
    while stream.tell() < stop:
        if record_format == 'VB':
            block_length = _word(stream, 'BDW', stop)
            limit = stream.tell() - 4 + block_length
        else:
            limit = stop
        while stream.tell() < limit:
            if record_format != 'F':
                size = _word(stream, 'RDW', limit) - 4
                if size != length:
                    raise ValueError('record length changed during conversion')
            else:
                size = length
            offset = stream.tell()
            raw = stream.read(size)
            if len(raw) != size:
                raise ValueError(f'truncated record at byte {offset}')
            yield offset, raw
