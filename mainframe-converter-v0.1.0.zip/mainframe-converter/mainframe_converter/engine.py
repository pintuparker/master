"""Bounded process execution and publish-on-success output directories."""
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
import csv
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import shutil
import tempfile
import time

from .framing import ranges, records
from .schema import parse_copybook


def _digest(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _identity(path):
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def _worker(task):
    source, stage, schema, fmt, delimiter, index, start, stop, expected = task
    target = Path(stage) / f'part-{index:08d}.csv'
    count = 0
    with open(source, 'rb') as stream, target.open('w', encoding='utf-8', newline='') as out:
        writer = csv.writer(out, delimiter=delimiter, lineterminator='\n')
        writer.writerow(schema.columns)
        for offset, raw in records(stream, start, stop, fmt, schema.length):
            try:
                writer.writerow(schema.decode(raw))
            except (ValueError, UnicodeError) as exc:
                # Do not include field contents in diagnostics.
                raise ValueError(f'decoding failed at source byte {offset}: {type(exc).__name__}') from exc
            count += 1
        out.flush()
        os.fsync(out.fileno())
    if count != expected:
        raise ValueError('partition record count mismatch')
    return {'file': target.name, 'records': count, 'source_start': start,
            'source_stop': stop, 'sha256': _digest(target)}


def convert(input_path, copybook_path, output_path, *, record_format='F',
            encoding='cp037', workers=1, batch_records=100000, delimiter=','):
    """Convert an immutable local input into a new directory of ordered CSV parts.

    Output must not exist. A sibling exclusive lock protects cooperating runs.
    All records fail closed; no silent replacements or partial publish. Input
    files must not be changed by external writers while a conversion runs.
    """
    if isinstance(workers, bool) or not isinstance(workers, int) or workers < 1:
        raise ValueError('workers must be a positive integer')
    if isinstance(batch_records, bool) or not isinstance(batch_records, int) or batch_records < 1:
        raise ValueError('batch_records must be a positive integer')
    if len(delimiter) != 1 or delimiter in '\r\n\x00"':
        raise ValueError('delimiter must be one character other than quote, NUL, CR, LF')
    if record_format not in ('F', 'V', 'VB'):
        raise ValueError('format must be F, V, or VB')
    source, copybook, output = map(lambda p: Path(p).resolve(),
                                   (input_path, copybook_path, output_path))
    if not source.is_file():
        raise ValueError('input must be a regular local file')
    schema_text = copybook.read_text(encoding='utf-8')
    schema = parse_copybook(schema_text, encoding)
    output.parent.mkdir(parents=True, exist_ok=True)
    lock = output.with_name(output.name + '.lock')
    fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    stage = None
    started = time.monotonic()
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(str(os.getpid()))
        if output.exists():
            raise FileExistsError(f'output already exists: {output}')
        before = _identity(source)
        stage = Path(tempfile.mkdtemp(prefix='.' + output.name + '-', dir=output.parent))
        tasks = ranges(source, record_format, schema.length, batch_records)
        results = []
        if workers == 1:
            for index, (start, stop, count) in enumerate(tasks):
                results.append(_worker((str(source), str(stage), schema, record_format,
                                        delimiter, index, start, stop, count)))
        else:
            # Spawn avoids dependence on inherited handles/state; works on Windows.
            with ProcessPoolExecutor(max_workers=workers,
                                     mp_context=multiprocessing.get_context('spawn')) as pool:
                pending = set()
                try:
                    for index, (start, stop, count) in enumerate(tasks):
                        pending.add(pool.submit(_worker, (str(source), str(stage), schema,
                                    record_format, delimiter, index, start, stop, count)))
                        if len(pending) >= workers * 2:
                            done, pending = wait(pending, return_when=FIRST_COMPLETED)
                            results.extend(f.result() for f in done)
                    while pending:
                        done, pending = wait(pending, return_when=FIRST_COMPLETED)
                        results.extend(f.result() for f in done)
                except BaseException:
                    for future in pending:
                        future.cancel()
                    raise
        if _identity(source) != before:
            raise RuntimeError('input changed during conversion; output not published')
        results.sort(key=lambda result: result['source_start'])
        manifest = {
            'package_version': '0.1.0', 'schema': schema.name,
            'copybook_sha256': hashlib.sha256(schema_text.encode('utf-8')).hexdigest(),
            'input_bytes': before[2], 'record_format': record_format,
            'record_length': schema.length, 'encoding': encoding,
            'delimiter': delimiter, 'columns': schema.columns,
            'workers': workers, 'records': sum(r['records'] for r in results),
            'elapsed_seconds': round(time.monotonic() - started, 4), 'parts': results,
        }
        if record_format == 'F' and manifest['records'] != before[2] // schema.length:
            raise RuntimeError('total record count mismatch')
        with (stage / 'manifest.json').open('w', encoding='utf-8') as stream:
            json.dump(manifest, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        if output.exists():
            raise FileExistsError(f'output appeared during conversion: {output}')
        stage.rename(output)
        stage = None
        return manifest
    finally:
        if stage is not None:
            shutil.rmtree(stage, ignore_errors=True)
        lock.unlink(missing_ok=True)
