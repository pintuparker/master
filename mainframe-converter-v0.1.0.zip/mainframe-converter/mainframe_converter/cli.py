import argparse
import json
import sys
from .engine import convert


def main():
    parser = argparse.ArgumentParser(description='Strict mainframe PIC X converter')
    parser.add_argument('--input', required=True)
    parser.add_argument('--copybook', required=True)
    parser.add_argument('--output', required=True, help='new directory, must not exist')
    parser.add_argument('--format', choices=['F', 'V', 'VB'], default='F')
    parser.add_argument('--encoding', default='cp037')
    parser.add_argument('--workers', type=int, default=1)
    parser.add_argument('--batch-records', type=int, default=100000)
    parser.add_argument('--delimiter', default=',')
    args = parser.parse_args()
    try:
        result = convert(args.input, args.copybook, args.output,
                         record_format=args.format, encoding=args.encoding,
                         workers=args.workers, batch_records=args.batch_records,
                         delimiter=args.delimiter)
    except (ValueError, OSError, RuntimeError) as exc:
        print(f'conversion failed: {exc}', file=sys.stderr)
        return 1
    print(json.dumps({'records': result['records'], 'parts': len(result['parts']),
                      'elapsed_seconds': result['elapsed_seconds']}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
