"""Strict grammar for one root and flat level-02 PIC X fields plus level-88 values.

Unsupported clauses are errors, never silently ignored. This is not a full
COBOL grammar. Byte-valued condition fields are emitted as uppercase hex.
"""
from dataclasses import dataclass
import codecs
import re


@dataclass(frozen=True)
class Condition:
    name: str
    value: bytes


@dataclass(frozen=True)
class Field:
    name: str
    offset: int
    length: int
    binary: bool
    conditions: tuple[Condition, ...]


@dataclass(frozen=True)
class Schema:
    name: str
    fields: tuple[Field, ...]
    encoding: str

    @property
    def length(self):
        return sum(f.length for f in self.fields)

    @property
    def columns(self):
        columns = []
        for f in self.fields:
            columns.append(f.name)
            columns.extend(f'{f.name}__{c.name}' for c in f.conditions)
        return columns

    def decode(self, record: bytes):
        if len(record) != self.length:
            raise ValueError(f'record length {len(record)} != expected {self.length}')
        result = []
        for f in self.fields:
            raw = record[f.offset:f.offset + f.length]
            # Trim only EBCDIC-decoded trailing spaces, not leading spaces or controls.
            result.append(raw.hex().upper() if f.binary else raw.decode(self.encoding, errors='strict').rstrip(' '))
            result.extend('true' if raw == c.value else 'false' for c in f.conditions)
        return result


def parse_copybook(text: str, encoding: str = 'cp037') -> Schema:
    codecs.lookup(encoding)
    try:
        single_byte = len(bytes(range(256)).decode(encoding, errors='strict')) == 256
    except UnicodeError:
        single_byte = False
    if not single_byte:
        raise ValueError('a complete single-byte mainframe encoding is required')
    declarations = []
    for number, original in enumerate(text.splitlines(), 1):
        line = original.rstrip()
        # Classic fixed-format sequence area and indicator, or relaxed pasted copybook.
        if len(line) > 6 and (line[:6].isdigit() or not line[:6].strip()):
            if line[6:7] in ('*', '/'):
                continue
            if line[6:7] == '-':
                raise ValueError(f'continuation lines unsupported at line {number}')
            if line[:6].isdigit():
                line = line[7:72]
        line = line.strip()
        if not line or line.startswith('*'):
            continue
        # Only complete declarations per line are supported in this initial grammar.
        declarations.append((number, line))
    root = None
    fields = []
    names = set()
    offset = 0
    for number, line in declarations:
        m = re.fullmatch(r'01\s+([\w-]+)\s*\.', line, re.I)
        if m:
            if root is not None or fields:
                raise ValueError('exactly one level-01 root is supported')
            root = m[1].upper()
            continue
        m = re.fullmatch(r'02\s+([\w-]+)\s+PIC(?:TURE)?\s+X(?:\((\d+)\))?\s*\.', line, re.I)
        if m:
            if root is None:
                raise ValueError('missing level-01 root')
            name, length = m[1].upper(), int(m[2] or 1)
            if name in names or name == 'FILLER' or length < 1 or length > 1048576:
                raise ValueError(f'invalid, duplicate, or unsupported field {name}')
            names.add(name)
            fields.append(Field(name, offset, length, False, ()))
            offset += length
            continue
        m = re.fullmatch(r"88\s+([\w-]+)\s+VALUE\s+(X'([0-9A-F]+)'|'([^']*)')\s*\.", line, re.I)
        if m and fields:
            field = fields[-1]
            name = m[1].upper()
            if any(c.name == name for c in field.conditions):
                raise ValueError(f'duplicate condition {name}')
            try:
                value = bytes.fromhex(m[3]) if m[3] is not None else m[4].encode(encoding)
            except (ValueError, UnicodeError) as exc:
                raise ValueError(f'invalid condition at line {number}') from exc
            if len(value) != field.length:
                raise ValueError(f'condition length mismatch at line {number}')
            fields[-1] = Field(field.name, field.offset, field.length,
                               field.binary or m[3] is not None,
                               field.conditions + (Condition(name, value),))
            continue
        raise ValueError(f'unsupported copybook declaration at line {number}: {line}')
    if root is None or not fields:
        raise ValueError('copybook must contain one root and at least one field')
    schema = Schema(root, tuple(fields), encoding)
    if len(schema.columns) != len(set(schema.columns)):
        raise ValueError('generated column name collision')
    return schema
