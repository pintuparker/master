import csv
import json
from pathlib import Path
import tempfile
import unittest
from mainframe_converter import parse_copybook, convert
from examples.generate_sample import generate, sample_record

COPYBOOK = Path(__file__).resolve().parents[1] / 'examples/EMASSTRT.cpy'


class ConversionTests(unittest.TestCase):
    def test_layout_and_raw_conditions(self):
        schema = parse_copybook(COPYBOOK.read_text())
        self.assertEqual(schema.length, 96)
        self.assertEqual([f.offset for f in schema.fields],
                         [0, 8, 16, 24, 32, 40, 48, 49, 50, 53, 83, 91])
        values = dict(zip(schema.columns, schema.decode(sample_record())))
        self.assertEqual(values['STATUS-R'], '80')
        self.assertEqual(values['STATUS-R__LOCAL'], 'true')
        self.assertEqual(values['STATUS-R__REMOTE'], 'false')
        self.assertEqual(values['DYNROUTE'], '01')
        self.assertEqual(values['DYNTYPE__WLMTOR'], 'true')
        remote = dict(zip(schema.columns, schema.decode(sample_record(True))))
        self.assertEqual(remote['STATUS-R'], '40')
        self.assertEqual(remote['STATUS-R__REMOTE'], 'true')
        self.assertEqual(remote['DYNROUTE__SUSPEND'], 'true')

    def test_f_v_vb_single_and_multi_process(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            generate(root, 217)
            baseline = None
            for fmt in ('F', 'V', 'VB'):
                for workers in (1, 2):
                    output = root / f'out-{fmt}-{workers}'
                    report = convert(root / f'sample.{fmt.lower()}.bin', COPYBOOK, output,
                                     record_format=fmt, workers=workers, batch_records=7)
                    self.assertEqual(report['records'], 217)
                    rows = []
                    for part in report['parts']:
                        with (output / part['file']).open(newline='') as stream:
                            rows.extend(csv.DictReader(stream))
                    if baseline is None:
                        baseline = rows
                    self.assertEqual(rows, baseline)
                    self.assertEqual(json.loads((output / 'manifest.json').read_text())['records'], 217)

    def test_fail_closed_unsupported_copybook(self):
        for clause in ('02 N PIC 9(4).', '02 G OCCURS 2 TIMES.',
                       '02 A PIC X REDEFINES B.', '88 C VALUE X\'ZZ\'.'):
            with self.subTest(clause=clause), self.assertRaises(ValueError):
                parse_copybook('01 ROOT.\n02 A PIC X.\n' + clause)

    def test_corruption_never_publishes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            cases = [('F', b'x'), ('V', b'\0'), ('V', b'\0\x64\x01\0' + sample_record()),
                     ('V', b'\0\x65\0\0' + sample_record()),
                     ('VB', b'\0\x68\0\0\0\x65\0\0' + sample_record())]
            for i, (fmt, data) in enumerate(cases):
                source, out = root / f'in{i}', root / f'out{i}'
                source.write_bytes(data)
                with self.assertRaises(ValueError):
                    convert(source, COPYBOOK, out, record_format=fmt, workers=2)
                self.assertFalse(out.exists())
                self.assertFalse(out.with_name(out.name + '.lock').exists())
                self.assertEqual(list(root.glob('.out*')), [])

    def test_csv_escaping_and_space_preservation(self):
        schema = parse_copybook('01 R.\n02 A PIC X(8).')
        self.assertEqual(schema.decode('  A,"B  '.encode('cp037')), ['  A,"B'])
        with self.assertRaises(ValueError):
            schema.decode(b'bad')

    def test_no_overwrite_and_empty(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            generate(root, 0)
            source, out = root / 'sample.f.bin', root / 'out'
            self.assertEqual(convert(source, COPYBOOK, out)['records'], 0)
            with self.assertRaises(FileExistsError):
                convert(source, COPYBOOK, out)
            self.assertTrue((out / 'manifest.json').exists())

    def test_arguments_and_sequence_columns(self):
        schema = parse_copybook('000100 01 ROOT.\n000200 02 TEXT PIC X(2).')
        self.assertEqual(schema.length, 2)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            generate(root, 1)
            for kwargs in ({'workers': 0}, {'batch_records': 0}, {'delimiter': '\n'},
                           {'record_format': 'VBS'}):
                with self.assertRaises(ValueError):
                    convert(root / 'sample.f.bin', COPYBOOK, root / 'out', **kwargs)


if __name__ == '__main__':
    unittest.main()
